stl package
===========

stl.Mesh
--------

.. autoclass:: stl.Mesh
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:

stl.main module
---------------

.. automodule:: stl.main
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:

stl.base module
---------------

.. automodule:: stl.base
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:

stl.mesh module
---------------

.. automodule:: stl.mesh
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:

stl.stl module
--------------

.. automodule:: stl.stl
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:

