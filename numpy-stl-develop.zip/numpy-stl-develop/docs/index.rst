Welcome to numpy-stl's documentation!
========================================

Contents:

.. toctree::
   :maxdepth: 4

   usage
   tests
   stl

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

